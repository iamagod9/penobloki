<?php
	$host = 'localhost';
	$name = 'root';
	$password = 'root';
	$database = 'testdb';

	$link = mysqli_connect($host, $name, $password, $database);
?>